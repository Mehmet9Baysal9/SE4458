const mysql = require('mysql');

// MySQL bağlantı bilgileri
const connection = mysql.createConnection({
  host: 'localhost',
  user: 'Bays9',
  password: '007Fearless007!',
  database: 'buyukolcekli'
});

// MySQL bağlantısını başlat
connection.connect((err) => {
  if (err) {
    console.error('MySQL bağlantı hatası:', err);
    return;
  }
  console.log('MySQL bağlantısı başarıyla kuruldu.');

  // Tabloyu silmek için SQL sorgusu
  const sql = 'DROP TABLE tuitions';

  // SQL sorgusunu çalıştır
  connection.query(sql, (err, result) => {
    if (err) {
      console.error('Tablo silme hatası:', err);
    } else {
      console.log('Tablo başarıyla silindi.');
    }
    // Bağlantıyı kapat
    connection.end();
  });
});
