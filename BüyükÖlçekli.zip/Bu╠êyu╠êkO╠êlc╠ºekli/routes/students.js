const express = require('express');
const router = express.Router();

/**
 * @swagger
 * /students/{studentId}:
 *   get:
 *     summary: Öğrenci bilgilerini döndürür
 *     description: Belirtilen ID'ye sahip öğrencinin tüm detaylarını döndürür
 *     parameters:
 *       - in: path
 *         name: studentId
 *         required: true
 *         description: Numeric ID of the student to get.
 *         schema:
 *           type: integer
 *     responses:
 *       200:
 *         description: Başarılı bir şekilde öğrenci bilgileri döndürüldü
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *               properties:
 *                 studentId:
 *                   type: integer
 *                   description: Öğrencinin ID'si
 *                   example: 101
 *                 name:
 *                   type: string
 *                   description: Öğrencinin ismi
 *                   example: Mehmet
 *                 age:
 *                   type: integer
 *                   description: Öğrencinin yaşı
 *                   example: 21
 *                 major:
 *                   type: string
 *                   description: Öğrencinin ana dalı
 *                   example: Bilgisayar Mühendisliği
 *       404:
 *         description: Öğrenci bulunamadı
 */

router.get('/:studentId', (req, res) => {
    // Öğrenci bilgilerini döndüren kod buraya yazılacak
    // Örnek olarak statik bir cevap gönderiliyor
    res.status(200).json({
        studentId: req.params.studentId,
        name: "Mehmet",
        age: 21,
        major: "Bilgisayar Mühendisliği"
    });
});

module.exports = router;
