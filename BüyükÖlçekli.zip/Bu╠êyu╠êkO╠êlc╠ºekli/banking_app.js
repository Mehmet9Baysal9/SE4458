const mysql = require('mysql');
const readline = require('readline');


const connection = mysql.createConnection({
  host: 'localhost',
  user: 'Bays9',
  password: '007Fearless007!',
  database: 'buyukolcekli'
});


connection.connect((err) => {
  if (err) {
    console.error('MySQL bağlantı hatası:', err);
    return;
  }
  console.log('MySQL bağlantısı başarıyla kuruldu.');
  authenticateStudent();
});


const rl = readline.createInterface({
  input: process.stdin,
  output: process.stdout
});


function authenticateStudent() {
  rl.question('Öğrenci numarasını giriniz: ', (studentId) => {
    rl.question('Şifre giriniz: ', (password) => {
      const studentQuery = 'SELECT * FROM tuitions WHERE student_id = ? AND password = ?';
      connection.query(studentQuery, [studentId, password], (err, results) => {
        if (err || results.length === 0) {
          console.error('Kimlik doğrulama başarısız.');
          rl.close();
          return;
        }
        console.log('Kimlik doğrulama başarılı.');
        startApp(studentId);
      });
    });
  });
}


function startApp(studentId) {
  rl.question('Dönemi girin (örn. 2024 Bahar): ', (term) => {
    getTuitionInfo(studentId, term);
  });
}


function getTuitionInfo(studentId, term) {
  
  const sql = `
    SELECT t.total_fee AS tuition_amount,
           t.amount_paid,
           t.current_balance,
           CASE
             WHEN t.amount_paid < t.total_fee THEN 'Onaylanmadı'
             WHEN t.amount_paid = t.total_fee THEN 'Onaylandı'
           END AS status
    FROM tuitions t
    WHERE t.student_id = ? AND t.term = ?
  `;

  connection.query(sql, [studentId, term], (err, results) => {
    if (err) {
      console.error('Sorgu hatası:', err);
      rl.close();
      return;
    }
    console.log('Öğrenci ödemeleri ve bakiyesi:');
    results.forEach(row => {
      console.log('----------------------');
      console.log('Öğrenci:', studentId);
      console.log('Dönem:', term);
      console.log('Öğrenim Ücreti:', row.tuition_amount);
      console.log('Ödenen Miktar:', row.amount_paid);
      console.log('Kalan Bakiye:', row.current_balance);
      console.log('Durum:', row.status);
      console.log('----------------------');
    });

    if (results.length === 0) {
      console.log('Belirtilen öğrenci numarası ve döneme ait kayıt bulunamadı.');
      rl.close();
      return;
    }

    if (results[0].status === 'Onaylanmadı') {
      askPaymentConfirmation(studentId, term, results[0].current_balance);
    } else {
      console.log('Tüm ödemeler tamamlandı.');
      rl.close();
    }
  });
}

// Ödemeyi onaylama işlemini gerçekleştiren fonksiyon
function askPaymentConfirmation(studentId, term, remainingAmount) {
  rl.question('Kalan tutarı ödemek ister misiniz? (Evet/Hayır): ', (answer) => {
    if (answer.toLowerCase() === 'evet') {
      makePayment(studentId, term, remainingAmount);
    } else {
      console.log('Ödeme yapılmadı.');
      rl.close();
    }
  });
}

// Ödeme işlemini gerçekleştiren fonksiyon
function makePayment(studentId, term, remainingAmount) {
  rl.question(`Ödenecek miktar (${remainingAmount} TL'den az olmalıdır): `, (paymentAmount) => {
    paymentAmount = parseFloat(paymentAmount);
    if (isNaN(paymentAmount) || paymentAmount <= 0 || paymentAmount > remainingAmount) {
      console.log('Geçersiz miktar. Lütfen geçerli bir miktar girin.');
      makePayment(studentId, term, remainingAmount);
      return;
    }

    const updateSql = `
  UPDATE tuitions
  SET amount_paid = amount_paid + ?
  WHERE student_id = ? AND term = ?
`;

connection.query(updateSql, [paymentAmount, studentId, term], (err, results) => {
  if (err) {
    console.error('Güncelleme hatası:', err);
    rl.close();
    return;
  }
  console.log('Ödeme başarıyla gerçekleştirildi.');
  getTuitionInfo(studentId, term); // Güncel bilgileri göster
});

  });
}



  