const mysql = require('mysql');
const readline = require('readline');

const connection = mysql.createConnection({
  host: 'localhost',
  user: 'Bays9',
  password: '007Fearless007!',
  database: 'buyukolcekli'
});


connection.connect((err) => {
  if (err) {
    console.error('MySQL bağlantı hatası:', err);
    return;
  }
  console.log('MySQL bağlantısı başarıyla kuruldu.');

  const rl = readline.createInterface({
    input: process.stdin,
    output: process.stdout
  });

  
  function authenticateAdmin(adminname, password, callback) {
    const sql = 'SELECT * FROM admins WHERE adminname = ? AND password = ?';
    connection.query(sql, [adminname, password], (err, results) => {
      if (err) {
        console.error('Kimlik doğrulama hatası:', err);
        callback(false);
      } else if (results.length > 0) {
        console.log('Kimlik doğrulama başarılı.');
        callback(true);
      } else {
        console.log('Hatalı kullanıcı adı veya şifre.');
        callback(false);
      }
    });
  }

  
  function updateTuition(studentId, term, totalFee) {
    const sql = `
      UPDATE tuitions
      SET total_fee = ?
      WHERE student_id = ? AND term = ?
    `;
    connection.query(sql, [totalFee, studentId, term], (err, results) => {
      if (err) {
        console.error('Güncelleme hatası:', err);
      } else if (results.affectedRows === 0) {
        console.log('Güncelleme yapılamadı, kayıt bulunamadı.');
      } else {
        console.log('Öğrenim ücreti başarıyla güncellendi.');
      }
    });
  }

  
  function listUnapprovedStudents(term, showAll = false) {
    let sql = `
      SELECT student_id, status
      FROM tuitions
      WHERE term = ? AND status = 'Onaylanmadı'
      LIMIT 5
    `;
    if (showAll) {
      sql = `
        SELECT student_id, status
        FROM tuitions
        WHERE term = ? AND status = 'Onaylanmadı'
      `;
    }

    connection.query(sql, [term], (err, results) => {
      if (err) {
        console.error('Sorgu hatası:', err);
      } else if (results.length === 0) {
        console.log('Bu dönem için onaylanmamış öğrenci bulunamadı.');
        rl.close();
        connection.end();
      } else {
        console.log('Onaylanmamış Öğrenciler:');
        results.forEach((student, index) => {
          console.log(`${index + 1}. ID: ${student.student_id}, Durum: ${student.status}`);
        });
        if (!showAll && results.length === 5) {
          rl.question('Tüm sonuçları görmek ister misiniz? (Evet/Hayır): ', (answer) => {
            if (answer.toLowerCase() === 'evet') {
              listUnapprovedStudents(term, true);
            } else {
              rl.close();
              connection.end();
            }
          });
        } else {
          rl.close();
          connection.end();
        }
      }
    });
  }

  
  rl.question('Admin kullanıcı adını girin: ', (adminname) => {
    rl.question('Admin şifresini girin: ', (password) => {
      authenticateAdmin(adminname, password, (authenticated) => {
        if (authenticated) {
          rl.question('İşlem türünü seçin (1: Öğrenim Ücreti Güncelleme, 2: Onaylanmamış Öğrencileri Listele): ', (option) => {
            if (option === '1') {
              rl.question('Öğrenci numarasını girin: ', (studentId) => {
                rl.question('Dönemi girin (örn. 2024 Bahar): ', (term) => {
                  rl.question('Yeni öğrenim ücretini girin: ', (totalFee) => {
                    updateTuition(studentId, term, totalFee);
                  });
                });
              });
            } else if (option === '2') {
              rl.question('Listelenecek dönemi girin (örn. 2024 Bahar): ', (term) => {
                listUnapprovedStudents(term);
              });
            } else {
              console.log('Geçersiz işlem türü.');
              rl.close();
              connection.end();
            }
          });
        } else {
          console.log('Yetkilendirme başarısız.');
          rl.close();
          connection.end();
        }
      });
    });
  });
});


// çalıştırmak için " node university_webSite_admin.js " 