const mysql = require('mysql');
const readline = require('readline');


const connection = mysql.createConnection({
  host: 'localhost',
  user: 'Bays9',
  password: '007Fearless007!',
  database: 'buyukolcekli'
});


connection.connect((err) => {
  if (err) {
    console.error('MySQL bağlantı hatası:', err);
    return;
  }
  console.log('MySQL bağlantısı başarıyla kuruldu.');
  promptStudentId();
});


const rl = readline.createInterface({
  input: process.stdin,
  output: process.stdout
});


function promptStudentId() {
  rl.question('Öğrenci numarasını giriniz: ', (studentId) => {
    getTuitionDetails(studentId);
  });
}


function getTuitionDetails(studentId) {
  const sql = `
    SELECT total_fee AS tuition_amount,
           current_balance2
    FROM tuitions
    WHERE student_id = ?
  `;

  connection.query(sql, [studentId], (err, results) => {
    if (err) {
      console.error('Sorgu hatası:', err);
      rl.close();
      return;
    }
    
    if (results.length === 0) {
      console.log('Belirtilen öğrenci numarasına ait kayıt bulunamadı.');
      rl.close();
      return;
    }

    console.log('Öğrenci ödemeleri ve bakiyesi:');
    results.forEach(row => {
      console.log('----------------------');
      console.log('Öğrenci:', studentId);
      console.log('Öğrenim Ücreti:', row.tuition_amount);
      console.log('Kalan Bakiye:', row.current_balance2);
      console.log('----------------------');
    });
    rl.close();
  });
}

